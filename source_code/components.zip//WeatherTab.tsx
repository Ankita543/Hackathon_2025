import { SearchData } from '../App';
import { Cloud, CloudRain, Sun, Wind } from 'lucide-react';

interface WeatherTabProps {
  searchData: SearchData;
}

export default function WeatherTab({ searchData }: WeatherTabProps) {
  const tripDays = Math.ceil((searchData.checkOut.getTime() - searchData.checkIn.getTime()) / (1000 * 60 * 60 * 24));
  
  // Generate weather data dynamically based on selected dates
  const weatherPatterns = [Sun, Cloud, Sun, CloudRain, Sun, Cloud, Sun];
  const conditions = ['Sunny', 'Partly Cloudy', 'Sunny', 'Light Rain', 'Sunny', 'Cloudy', 'Clear'];
  
  const weatherData = Array.from({ length: tripDays }, (_, index) => {
    const currentDate = new Date(searchData.checkIn);
    currentDate.setDate(currentDate.getDate() + index);
    
    const patternIndex = index % weatherPatterns.length;
    const isArrival = index === 0;
    const isDeparture = index === tripDays - 1;
    
    let dayLabel = `Day ${index + 1}`;
    if (isArrival) dayLabel += ' - Arrival';
    if (isDeparture) dayLabel += ' - Departure';
    
    return {
      date: currentDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      day: dayLabel,
      high: 29 + Math.floor(Math.random() * 4),
      low: 23 + Math.floor(Math.random() * 3),
      condition: conditions[patternIndex],
      icon: weatherPatterns[patternIndex],
      precipitation: patternIndex === 3 ? '40%' : `${Math.floor(Math.random() * 15)}%`,
      humidity: `${65 + Math.floor(Math.random() * 15)}%`,
      wind: `${10 + Math.floor(Math.random() * 10)} km/h`
    };
  });

  return (
    <div className="p-6">
      <div className="mb-6">
        <h3 className="text-2xl mb-2">Weather Forecast for Goa</h3>
        <p className="text-gray-600">
          {tripDays}-day forecast for your trip ({searchData.checkIn.toLocaleDateString()} - {searchData.checkOut.toLocaleDateString()})
        </p>
      </div>

      <div className={`grid gap-4 ${tripDays <= 3 ? 'grid-cols-1 md:grid-cols-3' : tripDays <= 5 ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-5' : 'grid-cols-1 md:grid-cols-2 lg:grid-cols-4'}`}>
        {weatherData.map((day, index) => {
          const Icon = day.icon;
          return (
            <div
              key={index}
              className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-6 hover:shadow-xl transition-all duration-300 hover:scale-105 cursor-pointer"
            >
              <div className="text-center mb-4">
                <p className="text-sm text-gray-600 mb-1">{day.date}</p>
                <p className="text-xs text-gray-500 mb-3">{day.day}</p>
                <Icon className="w-16 h-16 mx-auto text-yellow-500 mb-3" />
                <p className="text-sm mb-3">{day.condition}</p>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-3xl">
                    {day.high}°
                  </span>
                  <span className="text-xl text-gray-500">
                    {day.low}°
                  </span>
                </div>

                <div className="pt-3 border-t border-blue-200 space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Precipitation</span>
                    <span>{day.precipitation}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Humidity</span>
                    <span>{day.humidity}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Wind</span>
                    <div className="flex items-center gap-1">
                      <Wind className="w-3 h-3" />
                      <span>{day.wind}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Summary */}
      <div className="mt-8 bg-blue-50 rounded-xl p-6">
        <h4 className="text-xl mb-3">Weather Summary</h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white rounded-lg p-4">
            <p className="text-sm text-gray-600 mb-1">Average High</p>
            <p className="text-2xl">31°C</p>
          </div>
          <div className="bg-white rounded-lg p-4">
            <p className="text-sm text-gray-600 mb-1">Average Low</p>
            <p className="text-2xl">24°C</p>
          </div>
          <div className="bg-white rounded-lg p-4">
            <p className="text-sm text-gray-600 mb-1">Conditions</p>
            <p className="text-lg">Mostly Sunny</p>
          </div>
        </div>
        <p className="mt-4 text-sm text-gray-600">
          Perfect beach weather! Pack light clothing, sunscreen, and sunglasses. Slight chance of rain on Day 4, so bring a light jacket.
        </p>
      </div>
    </div>
  );
}
