import { useState } from 'react';
import { ZoomIn, ZoomOut, Search } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import vrboMapImage from 'figma:asset/a99cc506c5fa5170327d9c13dd7b0add2e59e45f.png';

interface MapViewProps {
  destination: string;
}

export default function MapView({ destination }: MapViewProps) {
  const [searchWhenMove, setSearchWhenMove] = useState(false);

  const properties = [
    { id: 1, price: 105, lat: 15.5, lng: 73.75 },
    { id: 2, price: 89, lat: 15.48, lng: 73.77 },
    { id: 3, price: 154, lat: 15.52, lng: 73.78 },
    { id: 4, price: 245, lat: 15.49, lng: 73.76 },
    { id: 5, price: 350, lat: 15.51, lng: 73.74 },
    { id: 6, price: 198, lat: 15.47, lng: 73.73 },
  ];

  return (
    <div className="relative w-full h-full">
      {/* Map Image */}
      <div className="absolute inset-0">
        <img
          src={vrboMapImage}
          alt="Map of Goa"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Map Controls */}
      <div className="absolute top-4 left-4 right-4 z-10">
        <div className="bg-white rounded-lg shadow-lg p-3 flex items-center gap-2">
          <Search className="w-4 h-4 text-gray-400" />
          <Input
            type="text"
            placeholder="Find a location to pin"
            className="border-0 focus-visible:ring-0"
          />
        </div>
      </div>

      {/* Search When Move Checkbox */}
      <div className="absolute top-20 right-4 z-10">
        <div className="bg-white rounded-lg shadow-lg px-4 py-2 flex items-center gap-2">
          <input
            type="checkbox"
            id="searchWhenMove"
            checked={searchWhenMove}
            onChange={(e) => setSearchWhenMove(e.target.checked)}
            className="w-4 h-4"
          />
          <label htmlFor="searchWhenMove" className="text-sm cursor-pointer">
            Search when I move map
          </label>
        </div>
      </div>

      {/* Zoom Controls */}
      <div className="absolute top-32 right-4 z-10 flex flex-col gap-2">
        <Button
          size="icon"
          variant="secondary"
          className="bg-white hover:bg-gray-100 shadow-lg"
        >
          <ZoomIn className="w-5 h-5" />
        </Button>
        <Button
          size="icon"
          variant="secondary"
          className="bg-white hover:bg-gray-100 shadow-lg"
        >
          <ZoomOut className="w-5 h-5" />
        </Button>
      </div>

      {/* Property Price Markers */}
      {properties.map((property) => (
        <div
          key={property.id}
          className="absolute transform -translate-x-1/2 -translate-y-1/2 z-20"
          style={{
            top: `${(property.lat - 15.4) * 800 + 200}px`,
            left: `${(property.lng - 73.7) * 800 + 200}px`,
          }}
        >
          <button className="bg-white hover:bg-blue-600 hover:text-white text-blue-600 px-3 py-1 rounded-full shadow-lg transition-all duration-300 hover:scale-110 border-2 border-blue-600">
            CA ${property.price}
          </button>
        </div>
      ))}
    </div>
  );
}
