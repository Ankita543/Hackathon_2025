import { useState } from 'react';
import { X } from 'lucide-react';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { SearchData } from '../App';
import WeatherTab from './WeatherTab';
import ItineraryTab from './ItineraryTab';
import MapTab from './MapTab';

interface LocalLensModalProps {
  searchData: SearchData;
  onClose: () => void;
}

export default function LocalLensModal({ searchData, onClose }: LocalLensModalProps) {
  const [activeTab, setActiveTab] = useState('weather');

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 animate-in fade-in duration-300">
      <div className="bg-white rounded-2xl w-full max-w-6xl max-h-[90vh] overflow-hidden shadow-2xl animate-in zoom-in-95 duration-300">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-4 flex items-center justify-between">
          <div>
            <h2 className="text-2xl">Local Lens - {searchData.destination}</h2>
            <p className="text-blue-100 text-sm">
              {searchData.checkIn.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - {searchData.checkOut.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
            </p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="text-white hover:bg-white/20"
          >
            <X className="w-6 h-6" />
          </Button>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="w-full grid grid-cols-3 rounded-none border-b bg-gray-50">
            <TabsTrigger
              value="weather"
              className="data-[state=active]:bg-white data-[state=active]:shadow-sm transition-all duration-300 hover:bg-white/50"
            >
              <span className="mr-2">☀️</span>
              Weather
            </TabsTrigger>
            <TabsTrigger
              value="itinerary"
              className="data-[state=active]:bg-white data-[state=active]:shadow-sm transition-all duration-300 hover:bg-white/50"
            >
              <span className="mr-2">📅</span>
              Itinerary
            </TabsTrigger>
            <TabsTrigger
              value="map"
              className="data-[state=active]:bg-white data-[state=active]:shadow-sm transition-all duration-300 hover:bg-white/50"
            >
              <span className="mr-2">🗺️</span>
              Map
            </TabsTrigger>
          </TabsList>

          <div className="overflow-y-auto max-h-[calc(90vh-140px)]">
            <TabsContent value="weather" className="m-0 animate-in fade-in-50 duration-500">
              <WeatherTab searchData={searchData} />
            </TabsContent>

            <TabsContent value="itinerary" className="m-0 animate-in fade-in-50 duration-500">
              <ItineraryTab searchData={searchData} />
            </TabsContent>

            <TabsContent value="map" className="m-0 animate-in fade-in-50 duration-500">
              <MapTab searchData={searchData} />
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </div>
  );
}
