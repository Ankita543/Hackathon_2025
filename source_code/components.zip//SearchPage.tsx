import { useState } from 'react';
import { motion } from 'motion/react';
import { Users, Search, Calendar as CalendarIcon } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { SearchData } from '../App';
import { Calendar } from './ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';

interface SearchPageProps {
  onSearch: (data: SearchData) => void;
}

export default function SearchPage({ onSearch }: SearchPageProps) {
  const [destination, setDestination] = useState('Goa, India');
  const [checkInDate, setCheckInDate] = useState<Date>(new Date('2025-12-09'));
  const [checkOutDate, setCheckOutDate] = useState<Date>(new Date('2025-12-13'));
  const [guests, setGuests] = useState(2);
  const [showCheckInCal, setShowCheckInCal] = useState(false);
  const [showCheckOutCal, setShowCheckOutCal] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    onSearch({
      destination,
      checkIn: checkInDate,
      checkOut: checkOutDate,
      guests
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center">
                <span className="text-white">V</span>
              </div>
              <span className="text-xl">vrbo</span>
            </div>
            <nav className="flex items-center gap-6 text-sm">
              <a href="#" className="hover:text-blue-600 transition-colors">Trip Boards</a>
              <a href="#" className="hover:text-blue-600 transition-colors">List your property</a>
              <a href="#" className="hover:text-blue-600 transition-colors">Help</a>
              <a href="#" className="hover:text-blue-600 transition-colors">My trips</a>
              <a href="#" className="hover:text-blue-600 transition-colors">Sign in</a>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <div className="container mx-auto px-4 py-20">
        <motion.div 
          className="max-w-4xl mx-auto text-center mb-12"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
        >
          <h1 className="text-5xl mb-4">Find your perfect vacation rental</h1>
          <p className="text-xl text-gray-600">Discover amazing places to stay with our enhanced Local Lens feature</p>
        </motion.div>

        {/* Search Box */}
        <motion.form 
          onSubmit={handleSubmit} 
          className="max-w-5xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2, ease: "easeOut" }}
        >
          <div className="bg-white rounded-lg shadow-xl p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
              {/* Destination */}
              <div className="md:col-span-1">
                <label className="block text-sm mb-2">Where</label>
                <Input
                  type="text"
                  value={destination}
                  onChange={(e) => setDestination(e.target.value)}
                  placeholder="Destination"
                  className="w-full"
                />
              </div>

              {/* Check-in */}
              <div>
                <label className="block text-sm mb-2">Check-in</label>
                <Popover open={showCheckInCal} onOpenChange={setShowCheckInCal}>
                  <PopoverTrigger asChild>
                    <Button
                      type="button"
                      variant="outline"
                      className="w-full justify-start text-left font-normal"
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {checkInDate ? checkInDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : 'Select date'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0 z-50" align="start">
                    <Calendar
                      mode="single"
                      selected={checkInDate}
                      onSelect={(date) => {
                        if (date) {
                          setCheckInDate(date);
                          // If check-out date is before new check-in, adjust it
                          if (checkOutDate <= date) {
                            const newCheckOut = new Date(date);
                            newCheckOut.setDate(newCheckOut.getDate() + 1);
                            setCheckOutDate(newCheckOut);
                          }
                          setShowCheckInCal(false);
                        }
                      }}
                      disabled={(date) => {
                        const today = new Date();
                        today.setHours(0, 0, 0, 0);
                        return date < today;
                      }}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>

              {/* Check-out */}
              <div>
                <label className="block text-sm mb-2">Check-out</label>
                <Popover open={showCheckOutCal} onOpenChange={setShowCheckOutCal}>
                  <PopoverTrigger asChild>
                    <Button
                      type="button"
                      variant="outline"
                      className="w-full justify-start text-left font-normal"
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {checkOutDate ? checkOutDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : 'Select date'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0 z-50" align="start">
                    <Calendar
                      mode="single"
                      selected={checkOutDate}
                      onSelect={(date) => {
                        if (date) {
                          setCheckOutDate(date);
                          setShowCheckOutCal(false);
                        }
                      }}
                      disabled={(date) => date <= checkInDate}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>

              {/* Guests */}
              <div>
                <label className="block text-sm mb-2">Guests</label>
                <div className="relative">
                  <Users className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    type="number"
                    value={guests}
                    onChange={(e) => setGuests(Number(e.target.value))}
                    min="1"
                    className="pl-10"
                  />
                </div>
              </div>
            </div>

            <Button type="submit" className="w-full md:w-auto bg-blue-600 hover:bg-blue-700 px-8">
              <Search className="w-4 h-4 mr-2" />
              Search
            </Button>
          </div>
        </motion.form>

        {/* Feature Cards */}
        <motion.div 
          className="max-w-5xl mx-auto mt-16 grid grid-cols-1 md:grid-cols-3 gap-6"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4, ease: "easeOut" }}
        >
          <div className="bg-white rounded-lg p-6 shadow-lg transform hover:scale-105 transition-transform duration-300">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
              <span className="text-2xl">☀️</span>
            </div>
            <h3 className="text-xl mb-2">Weather Forecast</h3>
            <p className="text-gray-600">Get detailed weather information for your travel dates</p>
          </div>

          <div className="bg-white rounded-lg p-6 shadow-lg transform hover:scale-105 transition-transform duration-300">
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-4">
              <span className="text-2xl">📅</span>
            </div>
            <h3 className="text-xl mb-2">Smart Itinerary</h3>
            <p className="text-gray-600">AI-powered trip planning with optimal routes and timing</p>
          </div>

          <div className="bg-white rounded-lg p-6 shadow-lg transform hover:scale-105 transition-transform duration-300">
            <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mb-4">
              <span className="text-2xl">🗺️</span>
            </div>
            <h3 className="text-xl mb-2">Interactive Map</h3>
            <p className="text-gray-600">Visualize your journey with marked attractions and dining</p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
