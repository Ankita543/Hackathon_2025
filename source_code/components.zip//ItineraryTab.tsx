import { useState } from 'react';
import { SearchData } from '../App';
import { MapPin, Clock, Sunrise, Sunset, ChevronDown, ChevronUp, ExternalLink, Utensils } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Button } from './ui/button';

interface ItineraryTabProps {
  searchData: SearchData;
}

interface DiningOption {
  name: string;
  type: string;
  distance: string;
  cuisine: string;
}

interface ItineraryStop {
  time: string;
  name: string;
  description: string;
  duration: string;
  isOptimal: boolean;
  googleLink: string;
  image: string;
  diningNearby: DiningOption[];
}

export default function ItineraryTab({ searchData }: ItineraryTabProps) {
  const [expandedDining, setExpandedDining] = useState<{ [key: string]: boolean }>({});

  const tripDays = Math.ceil((searchData.checkOut.getTime() - searchData.checkIn.getTime()) / (1000 * 60 * 60 * 24));

  const toggleDining = (key: string) => {
    setExpandedDining(prev => ({ ...prev, [key]: !prev[key] }));
  };

  // All available attractions for different days
  const allAttractions = [
    // Day 2 attractions
    [
      {
        time: '6:00 AM',
        name: 'Aguada Fort',
        description: 'Start your day early at the historic Aguada Fort. Built in 1612, this Portuguese fort offers stunning sunrise views over the Arabian Sea and the Mandovi River.',
        duration: '2 hours',
        isOptimal: true,
        googleLink: 'https://www.google.com/maps/place/Fort+Aguada',
        image: 'historic fort sunrise',
        diningNearby: [
          { name: 'Fort View Café', type: 'Café', distance: '0.1 km', cuisine: 'Coffee, Snacks' },
          { name: "Fisherman's Wharf", type: 'Restaurant', distance: '1.5 km', cuisine: 'Goan, Seafood' }
        ]
      },
      {
        time: '10:00 AM',
        name: 'Calangute Beach',
        description: 'Visit the "Queen of Beaches" - perfect for water sports and beach activities. Enjoy parasailing, jet skiing, or simply relax on the sandy shores.',
        duration: '3 hours',
        isOptimal: false,
        googleLink: 'https://www.google.com/maps/place/Calangute+Beach',
        image: 'beach water sports',
        diningNearby: [
          { name: 'Souza Lobo', type: 'Beach Restaurant', distance: '0.1 km', cuisine: 'Goan, Seafood' },
          { name: 'Café Chocolatti', type: 'Café', distance: '0.3 km', cuisine: 'Continental, Desserts' }
        ]
      },
      {
        time: '4:00 PM',
        name: 'Baga Beach',
        description: 'Head to Baga Beach for vibrant nightlife preparation. Famous for its beach shacks, water sports, and bustling atmosphere.',
        duration: '2 hours',
        isOptimal: false,
        googleLink: 'https://www.google.com/maps/place/Baga+Beach',
        image: 'baga beach sunset',
        diningNearby: [
          { name: "Britto's", type: 'Beach Shack', distance: '0.1 km', cuisine: 'Goan, Continental' },
          { name: "Tito's Restaurant", type: 'Casual Dining', distance: '0.2 km', cuisine: 'Multi-cuisine' }
        ]
      }
    ],
    // Day 3 attractions
    [
      {
        time: '8:00 AM',
        name: 'Dudhsagar Falls',
        description: 'Embark on an adventure to one of India\'s tallest waterfalls. The four-tiered waterfall cascades from a height of 310m, creating a milky white appearance.',
        duration: '5 hours (including travel)',
        isOptimal: false,
        googleLink: 'https://www.google.com/maps/place/Dudhsagar+Falls',
        image: 'waterfall nature',
        diningNearby: [
          { name: 'Dudhsagar Restaurant', type: 'Local Eatery', distance: '2 km', cuisine: 'Indian, Goan' },
          { name: 'Forest View Café', type: 'Café', distance: '1 km', cuisine: 'Snacks, Beverages' }
        ]
      },
      {
        time: '3:00 PM',
        name: 'Spice Plantation Tour',
        description: 'Visit a traditional spice plantation to learn about various spices like cardamom, pepper, and vanilla. Includes traditional Goan lunch.',
        duration: '3 hours',
        isOptimal: false,
        googleLink: 'https://www.google.com/maps/search/Spice+Plantation+Goa',
        image: 'spice plantation tour',
        diningNearby: [
          { name: 'Plantation Restaurant', type: 'Traditional', distance: '0 km', cuisine: 'Goan Buffet' },
          { name: 'Sahakari Spice Farm', type: 'Farm Restaurant', distance: '0.5 km', cuisine: 'Organic, Local' }
        ]
      }
    ],
    // Day 4 attractions
    [
      {
        time: '7:00 AM',
        name: 'Salaulim Dam',
        description: 'Experience the serene beauty of Salaulim Dam at sunrise. This lesser-known gem offers peaceful surroundings and beautiful photo opportunities.',
        duration: '2 hours',
        isOptimal: true,
        googleLink: 'https://www.google.com/maps/place/Salaulim+Dam',
        image: 'dam lake sunrise',
        diningNearby: [
          { name: 'Lakeview Dhaba', type: 'Local Eatery', distance: '1 km', cuisine: 'Indian, Snacks' },
          { name: 'Dam View Restaurant', type: 'Restaurant', distance: '0.8 km', cuisine: 'Goan, Chinese' }
        ]
      },
      {
        time: '11:00 AM',
        name: 'Old Goa Churches',
        description: 'Explore UNESCO World Heritage sites including Basilica of Bom Jesus and Se Cathedral. Discover Portuguese colonial architecture and rich history.',
        duration: '3 hours',
        isOptimal: false,
        googleLink: 'https://www.google.com/maps/place/Old+Goa',
        image: 'historic church architecture',
        diningNearby: [
          { name: 'Viva Panjim', type: 'Heritage Restaurant', distance: '2 km', cuisine: 'Goan, Portuguese' },
          { name: 'Black Sheep Bistro', type: 'Bistro', distance: '2.5 km', cuisine: 'European, Goan Fusion' }
        ]
      },
      {
        time: '5:30 PM',
        name: 'Chapora Fort',
        description: 'Famous Dil Chahta Hai fort! Perfect for sunset views overlooking Vagator Beach. The panoramic views are breathtaking.',
        duration: '1.5 hours',
        isOptimal: true,
        googleLink: 'https://www.google.com/maps/place/Chapora+Fort',
        image: 'chapora fort sunset',
        diningNearby: [
          { name: 'Antares Restaurant', type: 'Fine Dining', distance: '1 km', cuisine: 'Beach View, Continental' },
          { name: 'Thalassa', type: 'Greek Restaurant', distance: '0.5 km', cuisine: 'Greek, Mediterranean' }
        ]
      }
    ],
    // Day 5 attractions (additional)
    [
      {
        time: '7:00 AM',
        name: 'Arambol Beach',
        description: 'Experience a peaceful morning at Arambol Beach. Known for its bohemian vibe and stunning sunrise views.',
        duration: '2 hours',
        isOptimal: true,
        googleLink: 'https://www.google.com/maps/place/Arambol+Beach',
        image: 'beach sunrise peaceful',
        diningNearby: [
          { name: 'Beach Café Arambol', type: 'Café', distance: '0.1 km', cuisine: 'Continental, Healthy' },
          { name: 'Sunset Point Restaurant', type: 'Beach Shack', distance: '0.2 km', cuisine: 'Seafood' }
        ]
      },
      {
        time: '11:00 AM',
        name: 'Anjuna Flea Market',
        description: 'Shop at the famous Anjuna Flea Market (Wednesday market). Find unique souvenirs, handicrafts, jewelry, and local art.',
        duration: '3 hours',
        isOptimal: false,
        googleLink: 'https://www.google.com/maps/place/Anjuna+Flea+Market',
        image: 'market shopping colorful',
        diningNearby: [
          { name: 'German Bakery', type: 'Bakery', distance: '0.3 km', cuisine: 'Bakery, European' },
          { name: 'Artjuna Café', type: 'Café', distance: '0.4 km', cuisine: 'Organic, Vegan' }
        ]
      }
    ],
    // Day 6 attractions
    [
      {
        time: '6:30 AM',
        name: 'Butterfly Beach',
        description: 'Hidden gem accessible by boat. Perfect sunrise spot with pristine sands and the chance to spot dolphins.',
        duration: '3 hours',
        isOptimal: true,
        googleLink: 'https://www.google.com/maps/place/Butterfly+Beach',
        image: 'secluded beach',
        diningNearby: [
          { name: 'Beach Picnic', type: 'Packed', distance: '0 km', cuisine: 'Self-service' },
          { name: 'Palolem Restaurants', type: 'Various', distance: '2 km', cuisine: 'Multi-cuisine' }
        ]
      },
      {
        time: '12:00 PM',
        name: 'Cabo de Rama Fort',
        description: 'Ancient fort with spectacular cliff-top views. Less touristy, offering peaceful exploration and photography.',
        duration: '2 hours',
        isOptimal: false,
        googleLink: 'https://www.google.com/maps/place/Cabo+de+Rama+Fort',
        image: 'clifftop fort',
        diningNearby: [
          { name: 'Fort Café', type: 'Local', distance: '0.5 km', cuisine: 'Goan, Snacks' }
        ]
      }
    ],
    // Day 7 attractions
    [
      {
        time: '7:00 AM',
        name: 'Divar Island',
        description: 'Take a ferry to tranquil Divar Island. Explore Portuguese heritage, old churches, and village life.',
        duration: '4 hours',
        isOptimal: false,
        googleLink: 'https://www.google.com/maps/place/Divar+Island',
        image: 'island village heritage',
        diningNearby: [
          { name: 'Island Restaurant', type: 'Local', distance: '0.3 km', cuisine: 'Goan Home Style' }
        ]
      },
      {
        time: '2:00 PM',
        name: 'Mandrem Beach',
        description: 'Relax at peaceful Mandrem Beach. Known for cleanliness and calm waters, perfect for your last beach day.',
        duration: '3 hours',
        isOptimal: false,
        googleLink: 'https://www.google.com/maps/place/Mandrem+Beach',
        image: 'calm beach relaxing',
        diningNearby: [
          { name: 'Beach House', type: 'Beach Restaurant', distance: '0.1 km', cuisine: 'Fresh Seafood' }
        ]
      }
    ]
  ];

  // Generate dynamic itinerary based on trip days
  const generateItinerary = () => {
    const itinerary: { [key: string]: ItineraryStop[] } = {};
    
    // Day 1: Always arrival
    itinerary['Day 1'] = [{
      time: 'Arrival Day',
      name: 'Hotel Check-in & Relax',
      description: 'Arrive at Goa airport, transfer to your hotel, check-in and relax after your journey. Evening free to explore nearby area.',
      duration: 'Full Day',
      isOptimal: false,
      googleLink: 'https://maps.google.com',
      image: 'hotel resort checkin',
      diningNearby: [
        { name: 'Beach Shack Café', type: 'Casual', distance: '0.2 km', cuisine: 'Seafood, Indian' },
        { name: 'Sunset Restaurant', type: 'Fine Dining', distance: '0.5 km', cuisine: 'Continental' }
      ]
    }];

    // Middle days: Actual attractions
    const activeDays = tripDays - 2; // Exclude arrival and departure
    for (let i = 0; i < activeDays; i++) {
      const dayNumber = i + 2;
      const attractionIndex = Math.min(i, allAttractions.length - 1);
      itinerary[`Day ${dayNumber}`] = allAttractions[attractionIndex];
    }

    // Last day: Always departure
    itinerary[`Day ${tripDays}`] = [{
      time: 'Departure Day',
      name: 'Hotel Check-out & Shopping',
      description: 'Check out from hotel. If time permits, visit local markets for souvenirs - Mapusa Market or Anjuna Flea Market. Depart for airport.',
      duration: 'As per flight',
      isOptimal: false,
      googleLink: 'https://maps.google.com',
      image: 'local market shopping',
      diningNearby: [
        { name: 'Market Café', type: 'Quick Bite', distance: '0.1 km', cuisine: 'Snacks, Beverages' },
        { name: 'Airport Lounge', type: 'Lounge', distance: 'Airport', cuisine: 'Multi-cuisine' }
      ]
    }];

    return itinerary;
  };

  const itinerary = generateItinerary();

  return (
    <div className="p-6">
      <div className="mb-6">
        <h3 className="text-2xl mb-2">Your {tripDays}-Day Goa Itinerary</h3>
        <p className="text-gray-600">
          Optimized route covering {tripDays} days from {searchData.checkIn.toLocaleDateString()} to {searchData.checkOut.toLocaleDateString()}
        </p>
        <div className="mt-3 flex gap-2 text-sm">
          <div className="flex items-center gap-1">
            <Sunrise className="w-4 h-4 text-orange-500" />
            <span>Best at sunrise/sunset</span>
          </div>
          <span className="text-gray-400">|</span>
          <div className="flex items-center gap-1">
            <Utensils className="w-4 h-4 text-green-600" />
            <span>Dining options available</span>
          </div>
        </div>
      </div>

      {/* Itinerary Timeline */}
      <div className="space-y-8">
        {Object.entries(itinerary).map(([day, stops]) => (
          <div key={day} className="relative">
            {/* Day Header */}
            <div className="sticky top-0 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-t-xl px-6 py-3 z-10">
              <h4 className="text-xl">{day}</h4>
            </div>

            {/* Stops */}
            <div className="border-l-4 border-blue-200 ml-6 space-y-6 py-4">
              {stops.map((stop, index) => (
                <div key={index} className="relative pl-8">
                  {/* Timeline Dot */}
                  <div className="absolute -left-[13px] top-6 w-6 h-6 bg-blue-600 rounded-full border-4 border-white shadow-lg" />

                  {/* Stop Card */}
                  <div className="bg-white rounded-xl shadow-lg hover:shadow-2xl transition-all duration-300 hover:scale-[1.02] overflow-hidden">
                    <div className="flex flex-col md:flex-row">
                      {/* Image */}
                      <div className="w-full md:w-64 h-48 relative flex-shrink-0">
                        <ImageWithFallback
                          src={`https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400`}
                          alt={stop.name}
                          className="w-full h-full object-cover"
                        />
                        {stop.isOptimal && (
                          <div className="absolute top-2 right-2 bg-orange-500 text-white px-2 py-1 rounded-full text-xs flex items-center gap-1">
                            {stop.time.includes('AM') && (stop.time.startsWith('6') || stop.time.startsWith('7')) ? (
                              <><Sunrise className="w-3 h-3" /> Sunrise View</>
                            ) : (
                              <><Sunset className="w-3 h-3" /> Sunset View</>
                            )}
                          </div>
                        )}
                      </div>

                      {/* Content */}
                      <div className="flex-1 p-6">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <div className="flex items-center gap-2 mb-2">
                              <Clock className="w-4 h-4 text-blue-600" />
                              <span className="text-sm text-blue-600">{stop.time}</span>
                              <span className="text-sm text-gray-500">• {stop.duration}</span>
                            </div>
                            <h5 className="text-xl mb-2">{stop.name}</h5>
                          </div>
                          <a
                            href={stop.googleLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-1 text-sm text-blue-600 hover:text-blue-800 transition-colors"
                          >
                            <MapPin className="w-4 h-4" />
                            <span>View on Map</span>
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        </div>

                        <p className="text-gray-700 mb-4">{stop.description}</p>

                        {/* Dining Options Dropdown */}
                        <div className="border-t pt-4">
                          <button
                            onClick={() => toggleDining(`${day}-${index}`)}
                            className="flex items-center justify-between w-full text-left hover:bg-gray-50 p-2 rounded-lg transition-colors"
                          >
                            <div className="flex items-center gap-2">
                              <Utensils className="w-4 h-4 text-green-600" />
                              <span className="text-sm">
                                Nearby Dining Options ({stop.diningNearby.length})
                              </span>
                            </div>
                            {expandedDining[`${day}-${index}`] ? (
                              <ChevronUp className="w-4 h-4" />
                            ) : (
                              <ChevronDown className="w-4 h-4" />
                            )}
                          </button>

                          {expandedDining[`${day}-${index}`] && (
                            <div className="mt-3 space-y-2 animate-in slide-in-from-top-2 duration-300">
                              {stop.diningNearby.map((dining, dIndex) => (
                                <div
                                  key={dIndex}
                                  className="bg-green-50 rounded-lg p-3 hover:bg-green-100 transition-colors cursor-pointer"
                                >
                                  <div className="flex justify-between items-start">
                                    <div>
                                      <p className="font-medium">{dining.name}</p>
                                      <p className="text-sm text-gray-600">{dining.cuisine}</p>
                                    </div>
                                    <div className="text-right">
                                      <p className="text-xs text-gray-500">{dining.type}</p>
                                      <p className="text-xs text-blue-600">{dining.distance}</p>
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Summary */}
      <div className="mt-8 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-6">
        <h4 className="text-xl mb-3">Trip Summary</h4>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <p className="text-3xl mb-1">{Object.values(itinerary).flat().length}</p>
            <p className="text-sm text-gray-600">Total Stops</p>
          </div>
          <div className="text-center">
            <p className="text-3xl mb-1">{tripDays}</p>
            <p className="text-sm text-gray-600">Days</p>
          </div>
          <div className="text-center">
            <p className="text-3xl mb-1">~{tripDays * 30}</p>
            <p className="text-sm text-gray-600">Total km</p>
          </div>
          <div className="text-center">
            <p className="text-3xl mb-1">{Object.values(itinerary).flat().reduce((acc, stop) => acc + stop.diningNearby.length, 0)}</p>
            <p className="text-sm text-gray-600">Dining Options</p>
          </div>
        </div>
      </div>
    </div>
  );
}
