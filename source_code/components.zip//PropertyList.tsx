import { motion } from 'motion/react';
import { Heart, Star } from 'lucide-react';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface PropertyListProps {
  destination: string;
}

export default function PropertyList({ destination }: PropertyListProps) {
  const properties = [
    {
      id: 1,
      name: 'Beachside Beauty in Regal Park, Candolim',
      type: 'Apartment',
      sleeps: 4,
      bedrooms: 2,
      price: 105,
      rating: 4.8,
      reviews: 124,
      image: 'beach resort sunset',
      badge: 'Exceptional',
      amenities: ['Pool', 'Garden Views'],
      distance: '6 min walk to Candolim Beach'
    },
    {
      id: 2,
      name: 'HI GOA - Escape into Paradise',
      type: 'Apartment',
      sleeps: 6,
      bedrooms: 1,
      bathroom: 1,
      price: 89,
      rating: 4.6,
      reviews: 89,
      image: 'modern apartment interior',
      distance: '0.4 mi to Borda de França center'
    },
    {
      id: 3,
      name: 'Luxury Villa with Ocean View',
      type: 'Villa',
      sleeps: 8,
      bedrooms: 3,
      bathroom: 2,
      price: 245,
      rating: 4.9,
      reviews: 167,
      image: 'luxury villa pool',
      badge: 'Exceptional',
      amenities: ['Private Pool', 'Ocean View']
    },
    {
      id: 4,
      name: 'Cozy Beach Cottage in Baga',
      type: 'Cottage',
      sleeps: 4,
      bedrooms: 2,
      bathroom: 1,
      price: 125,
      rating: 4.7,
      reviews: 95,
      image: 'beach cottage',
      amenities: ['Beach Access', 'AC']
    },
    {
      id: 5,
      name: 'Modern Loft in Panjim City',
      type: 'Loft',
      sleeps: 2,
      bedrooms: 1,
      bathroom: 1,
      price: 78,
      rating: 4.5,
      reviews: 56,
      image: 'modern loft interior',
      distance: 'City Center'
    },
    {
      id: 6,
      name: 'Tropical Paradise Resort',
      type: 'Resort',
      sleeps: 10,
      bedrooms: 4,
      bathroom: 3,
      price: 350,
      rating: 5.0,
      reviews: 234,
      image: 'tropical resort',
      badge: 'Exceptional',
      amenities: ['Full Service', 'Spa', 'Restaurant']
    }
  ];

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl">300+ properties</h2>
        <div className="flex gap-2">
          <button className="px-4 py-2 border rounded-lg hover:bg-gray-50 transition-colors">
            Filters
          </button>
          <button className="px-4 py-2 border rounded-lg hover:bg-gray-50 transition-colors">
            Sort by recommended
          </button>
        </div>
      </div>

      {/* Destination Categories */}
      <div className="mb-6">
        <h3 className="mb-3">Destinations in Goa</h3>
        <div className="flex gap-2 flex-wrap">
          {['Beach', 'Family', 'Romance', 'Relaxation', 'Culture'].map((cat) => (
            <button
              key={cat}
              className="px-4 py-2 border rounded-lg hover:bg-blue-50 hover:border-blue-600 transition-all duration-300"
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Properties */}
      <div className="space-y-6">
        {properties.map((property, index) => (
          <motion.div
            key={property.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ 
              duration: 0.4, 
              delay: index * 0.1,
              ease: "easeOut"
            }}
            whileHover={{ scale: 1.02 }}
            className="flex gap-4 border rounded-lg overflow-hidden hover:shadow-lg transition-shadow duration-300 cursor-pointer bg-white"
          >
            <div className="relative w-64 h-48 flex-shrink-0">
              <ImageWithFallback
                src={`https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400`}
                alt={property.name}
                className="w-full h-full object-cover"
              />
              <button className="absolute top-3 right-3 w-8 h-8 bg-white rounded-full flex items-center justify-center hover:bg-gray-100 transition-colors">
                <Heart className="w-4 h-4" />
              </button>
              {property.badge && (
                <Badge className="absolute bottom-3 left-3 bg-blue-600">
                  {property.badge}
                </Badge>
              )}
            </div>

            <div className="flex-1 p-4 flex flex-col justify-between">
              <div>
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">{property.distance}</p>
                    <h3 className="text-lg mb-1">{property.name}</h3>
                    <p className="text-sm text-gray-600">
                      {property.type} · Sleeps {property.sleeps} · {property.bedrooms} bedrooms
                      {property.bathroom && ` · ${property.bathroom} bathroom`}
                    </p>
                  </div>
                </div>

                {property.amenities && (
                  <div className="flex gap-2 mt-2">
                    {property.amenities.map((amenity) => (
                      <span key={amenity} className="text-xs bg-gray-100 px-2 py-1 rounded">
                        {amenity}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex items-end justify-between mt-4">
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    <span>{property.rating}</span>
                  </div>
                  <span className="text-sm text-gray-600">({property.reviews} reviews)</span>
                </div>
                <div className="text-right">
                  <div className="text-2xl">CA ${property.price}</div>
                  <div className="text-sm text-gray-600">CA ${property.price * 5} total</div>
                  <div className="text-xs text-gray-500">includes taxes & fees</div>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
