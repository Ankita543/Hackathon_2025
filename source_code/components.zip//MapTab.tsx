import { useState } from 'react';
import { SearchData } from '../App';
import { ZoomIn, ZoomOut, Navigation, Home, Utensils, MapPin } from 'lucide-react';
import { Button } from './ui/button';
import goaMapImage from 'figma:asset/a99cc506c5fa5170327d9c13dd7b0add2e59e45f.png';

interface MapTabProps {
  searchData: SearchData;
}

interface MapMarker {
  id: string;
  name: string;
  type: 'attraction' | 'hotel' | 'dining';
  day?: number;
  x: number;
  y: number;
}

export default function MapTab({ searchData }: MapTabProps) {
  const [zoomLevel, setZoomLevel] = useState(1);
  const [hoveredMarker, setHoveredMarker] = useState<string | null>(null);
  const [showAttractions, setShowAttractions] = useState(true);
  const [showHotels, setShowHotels] = useState(true);
  const [showDining, setShowDining] = useState(true);

  const tripDays = Math.ceil((searchData.checkOut.getTime() - searchData.checkIn.getTime()) / (1000 * 60 * 60 * 24));
  const activeDays = tripDays - 2; // Exclude arrival and departure days

  // Map markers for attractions (connected by route)
  const attractions: MapMarker[] = [
    { id: 'aguada', name: 'Aguada Fort', type: 'attraction', day: 2, x: 45, y: 25 },
    { id: 'calangute', name: 'Calangute Beach', type: 'attraction', day: 2, x: 42, y: 28 },
    { id: 'baga', name: 'Baga Beach', type: 'attraction', day: 2, x: 44, y: 30 },
    { id: 'dudhsagar', name: 'Dudhsagar Falls', type: 'attraction', day: 3, x: 75, y: 35 },
    { id: 'spice', name: 'Spice Plantation', type: 'attraction', day: 3, x: 68, y: 40 },
    { id: 'salaulim', name: 'Salaulim Dam', type: 'attraction', day: 4, x: 70, y: 55 },
    { id: 'oldgoa', name: 'Old Goa Churches', type: 'attraction', day: 4, x: 50, y: 45 },
    { id: 'chapora', name: 'Chapora Fort', type: 'attraction', day: 4, x: 46, y: 32 },
  ];

  // Hotels
  const hotels: MapMarker[] = [
    { id: 'hotel1', name: 'Beach Resort Candolim', type: 'hotel', x: 43, y: 27 },
    { id: 'hotel2', name: 'Luxury Villa Baga', type: 'hotel', x: 45, y: 31 },
    { id: 'hotel3', name: 'Heritage Hotel Old Goa', type: 'hotel', x: 51, y: 44 },
    { id: 'hotel4', name: 'Riverside Resort Panjim', type: 'hotel', x: 48, y: 42 },
    { id: 'hotel5', name: 'Boutique Stay Vagator', type: 'hotel', x: 47, y: 33 },
  ];

  // Dining
  const dining: MapMarker[] = [
    { id: 'dining1', name: "Fisherman's Wharf", type: 'dining', x: 44, y: 26 },
    { id: 'dining2', name: 'Souza Lobo', type: 'dining', x: 42, y: 29 },
    { id: 'dining3', name: "Britto's Beach Shack", type: 'dining', x: 44, y: 31 },
    { id: 'dining4', name: 'Viva Panjim', type: 'dining', x: 49, y: 43 },
    { id: 'dining5', name: 'Thalassa Greek', type: 'dining', x: 46, y: 33 },
    { id: 'dining6', name: 'Plantation Restaurant', type: 'dining', x: 67, y: 41 },
  ];

  const handleZoomIn = () => {
    setZoomLevel(prev => Math.min(prev + 0.2, 2));
  };

  const handleZoomOut = () => {
    setZoomLevel(prev => Math.max(prev - 0.2, 0.6));
  };

  const allMarkers = [
    ...(showAttractions ? attractions : []),
    ...(showHotels ? hotels : []),
    ...(showDining ? dining : [])
  ];

  return (
    <div className="p-6">
      <div className="mb-6">
        <h3 className="text-2xl mb-2">Interactive Route Map</h3>
        <p className="text-gray-600">
          Explore your {tripDays}-day journey with marked attractions, hotels, and dining options
        </p>
      </div>

      {/* Legend */}
      <div className="mb-4 flex flex-wrap gap-4 items-center bg-gray-50 p-4 rounded-lg">
        <span className="font-medium">Show:</span>
        <label className="flex items-center gap-2 cursor-pointer">
          <input
            type="checkbox"
            checked={showAttractions}
            onChange={(e) => setShowAttractions(e.target.checked)}
            className="w-4 h-4"
          />
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 bg-blue-600 rounded-full" />
            <span className="text-sm">Attractions ({attractions.length})</span>
          </div>
        </label>
        <label className="flex items-center gap-2 cursor-pointer">
          <input
            type="checkbox"
            checked={showHotels}
            onChange={(e) => setShowHotels(e.target.checked)}
            className="w-4 h-4"
          />
          <div className="flex items-center gap-1">
            <Home className="w-3 h-3 text-purple-600" />
            <span className="text-sm">Hotels ({hotels.length})</span>
          </div>
        </label>
        <label className="flex items-center gap-2 cursor-pointer">
          <input
            type="checkbox"
            checked={showDining}
            onChange={(e) => setShowDining(e.target.checked)}
            className="w-4 h-4"
          />
          <div className="flex items-center gap-1">
            <Utensils className="w-3 h-3 text-green-600" />
            <span className="text-sm">Dining ({dining.length})</span>
          </div>
        </label>
      </div>

      {/* Map Container */}
      <div className="relative bg-gray-100 rounded-xl overflow-hidden shadow-xl" style={{ height: '600px' }}>
        {/* Map Image with Zoom */}
        <div
          className="absolute inset-0 transition-transform duration-300"
          style={{
            transform: `scale(${zoomLevel})`,
            transformOrigin: 'center center'
          }}
        >
          <img
            src={goaMapImage}
            alt="Goa Map"
            className="w-full h-full object-cover"
          />

          {/* Route Lines - Only connect attractions */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none">
            {showAttractions && attractions.slice(0, -1).map((marker, index) => {
              const nextMarker = attractions[index + 1];
              return (
                <line
                  key={`line-${marker.id}`}
                  x1={`${marker.x}%`}
                  y1={`${marker.y}%`}
                  x2={`${nextMarker.x}%`}
                  y2={`${nextMarker.y}%`}
                  stroke="#2563eb"
                  strokeWidth="3"
                  strokeDasharray="5,5"
                  className="animate-pulse"
                />
              );
            })}
          </svg>

          {/* Markers */}
          {allMarkers.map((marker) => (
            <div
              key={marker.id}
              className="absolute transform -translate-x-1/2 -translate-y-1/2 transition-all duration-300"
              style={{
                left: `${marker.x}%`,
                top: `${marker.y}%`,
                zIndex: hoveredMarker === marker.id ? 50 : marker.type === 'attraction' ? 30 : 20
              }}
              onMouseEnter={() => setHoveredMarker(marker.id)}
              onMouseLeave={() => setHoveredMarker(null)}
            >
              {/* Marker Pin */}
              <div className="relative">
                {marker.type === 'attraction' && (
                  <div className={`
                    w-10 h-10 rounded-full flex items-center justify-center
                    bg-blue-600 text-white border-4 border-white shadow-lg
                    cursor-pointer transition-all duration-300
                    ${hoveredMarker === marker.id ? 'scale-125' : 'hover:scale-110'}
                  `}>
                    <span className="text-sm">{marker.day}</span>
                  </div>
                )}
                {marker.type === 'hotel' && (
                  <div className={`
                    w-8 h-8 rounded-full flex items-center justify-center
                    bg-purple-600 text-white border-3 border-white shadow-lg
                    cursor-pointer transition-all duration-300
                    ${hoveredMarker === marker.id ? 'scale-125' : 'hover:scale-110'}
                  `}>
                    <Home className="w-4 h-4" />
                  </div>
                )}
                {marker.type === 'dining' && (
                  <div className={`
                    w-8 h-8 rounded-full flex items-center justify-center
                    bg-green-600 text-white border-3 border-white shadow-lg
                    cursor-pointer transition-all duration-300
                    ${hoveredMarker === marker.id ? 'scale-125' : 'hover:scale-110'}
                  `}>
                    <Utensils className="w-4 h-4" />
                  </div>
                )}

                {/* Tooltip on Hover */}
                {hoveredMarker === marker.id && (
                  <div className="absolute left-1/2 -translate-x-1/2 -top-16 bg-white px-3 py-2 rounded-lg shadow-xl whitespace-nowrap animate-in fade-in zoom-in-95 duration-200">
                    <p className="font-medium text-sm">{marker.name}</p>
                    {marker.day && (
                      <p className="text-xs text-gray-600">Day {marker.day}</p>
                    )}
                    <div className="absolute left-1/2 -translate-x-1/2 -bottom-1 w-2 h-2 bg-white transform rotate-45" />
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Zoom Controls */}
        <div className="absolute top-4 right-4 z-40 flex flex-col gap-2">
          <Button
            size="icon"
            onClick={handleZoomIn}
            className="bg-white text-gray-800 hover:bg-gray-100 shadow-lg"
          >
            <ZoomIn className="w-5 h-5" />
          </Button>
          <Button
            size="icon"
            onClick={handleZoomOut}
            className="bg-white text-gray-800 hover:bg-gray-100 shadow-lg"
          >
            <ZoomOut className="w-5 h-5" />
          </Button>
          <div className="bg-white px-3 py-1 rounded shadow-lg text-sm">
            {Math.round(zoomLevel * 100)}%
          </div>
        </div>

        {/* Map Info */}
        <div className="absolute bottom-4 left-4 z-40 bg-white/95 backdrop-blur-sm rounded-lg p-4 shadow-lg max-w-xs">
          <h4 className="font-medium mb-2">Route Overview</h4>
          <div className="space-y-1 text-sm">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-blue-600" />
              <span>Total Distance: ~120 km</span>
            </div>
            <div className="flex items-center gap-2">
              <Navigation className="w-4 h-4 text-green-600" />
              <span>Optimized for minimal travel</span>
            </div>
          </div>
        </div>
      </div>

      {/* Day-wise Breakdown */}
      <div className={`mt-6 grid gap-4 ${activeDays <= 2 ? 'grid-cols-1 md:grid-cols-3' : activeDays === 3 ? 'grid-cols-1 md:grid-cols-4' : 'grid-cols-1 md:grid-cols-3 lg:grid-cols-4'}`}>
        {Array.from({ length: activeDays }, (_, i) => i + 2).map((day) => {
          const dayAttractions = attractions.filter(a => a.day === day);
          return (
            <div key={day} className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-4">
              <h5 className="font-medium mb-2">Day {day}</h5>
              <div className="space-y-2 text-sm">
                {dayAttractions.length > 0 ? (
                  dayAttractions.map((attraction) => (
                    <div key={attraction.id} className="flex items-center gap-2">
                      <div className="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs">
                        {day}
                      </div>
                      <span className="text-xs">{attraction.name}</span>
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-gray-500">Explore local attractions</p>
                )}
              </div>
            </div>
          );
        })}
        <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg p-4">
          <h5 className="font-medium mb-2">Hotels Nearby</h5>
          <p className="text-sm text-gray-600">{hotels.length} properties along your route</p>
          <p className="text-xs text-gray-500 mt-2">Click markers to explore options</p>
        </div>
      </div>
    </div>
  );
}
