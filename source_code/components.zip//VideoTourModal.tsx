import { useState, useEffect } from 'react';
import { X, Play, Pause, RotateCcw } from 'lucide-react';
import { Button } from './ui/button';
import { SearchData } from '../App';
import { Progress } from './ui/progress';

interface VideoTourModalProps {
  searchData: SearchData;
  onClose: () => void;
}

export default function VideoTourModal({ searchData, onClose }: VideoTourModalProps) {
  const [isPlaying, setIsPlaying] = useState(true);
  const [currentStep, setCurrentStep] = useState(0);
  const [progress, setProgress] = useState(0);

  const tourSteps = [
    {
      title: 'Welcome to Your Trip',
      description: `Planning your ${Math.ceil((searchData.checkOut.getTime() - searchData.checkIn.getTime()) / (1000 * 60 * 60 * 24))}-day journey to ${searchData.destination}`,
      duration: 3000,
      emoji: '✈️'
    },
    {
      title: 'Check the Weather',
      description: 'Get detailed weather forecasts for all your travel dates',
      duration: 3000,
      emoji: '☀️'
    },
    {
      title: 'Smart Itinerary',
      description: 'AI-powered route planning optimized for sunrise/sunset views and minimal travel distance',
      duration: 4000,
      emoji: '📅'
    },
    {
      title: 'Discover Attractions',
      description: 'Visit historic forts, beautiful beaches, waterfalls, and cultural sites',
      duration: 4000,
      emoji: '🏛️'
    },
    {
      title: 'Find Dining Options',
      description: 'Explore nearby restaurants and local cuisine at every stop',
      duration: 3000,
      emoji: '🍽️'
    },
    {
      title: 'Interactive Map',
      description: 'Visualize your journey with marked routes, hotels, and dining spots',
      duration: 4000,
      emoji: '🗺️'
    },
    {
      title: 'Book Properties',
      description: 'Find and book the perfect accommodation along your route',
      duration: 3000,
      emoji: '🏨'
    },
    {
      title: 'Ready to Explore!',
      description: 'Your complete travel companion for an unforgettable trip',
      duration: 3000,
      emoji: '🎉'
    }
  ];

  useEffect(() => {
    if (!isPlaying) return;

    const step = tourSteps[currentStep];
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          // Move to next step
          if (currentStep < tourSteps.length - 1) {
            setCurrentStep(prev => prev + 1);
            return 0;
          } else {
            setIsPlaying(false);
            return 100;
          }
        }
        return prev + (100 / (step.duration / 100));
      });
    }, 100);

    return () => clearInterval(interval);
  }, [isPlaying, currentStep]);

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const handleRestart = () => {
    setCurrentStep(0);
    setProgress(0);
    setIsPlaying(true);
  };

  const currentTourStep = tourSteps[currentStep];

  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 animate-in fade-in duration-300">
      <div className="bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 rounded-2xl w-full max-w-4xl overflow-hidden shadow-2xl animate-in zoom-in-95 duration-300">
        {/* Header */}
        <div className="bg-black/20 backdrop-blur-sm px-6 py-4 flex items-center justify-between">
          <h2 className="text-2xl text-white">Local Lens Video Tour</h2>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="text-white hover:bg-white/20"
          >
            <X className="w-6 h-6" />
          </Button>
        </div>

        {/* Video Content */}
        <div className="p-12 text-white text-center min-h-[500px] flex flex-col items-center justify-center">
          <div className="text-8xl mb-8 animate-in zoom-in-50 duration-500">
            {currentTourStep.emoji}
          </div>
          <h3 className="text-4xl mb-6 animate-in slide-in-from-bottom-4 duration-500">
            {currentTourStep.title}
          </h3>
          <p className="text-xl text-white/90 max-w-2xl animate-in slide-in-from-bottom-4 duration-500 delay-150">
            {currentTourStep.description}
          </p>

          {/* Step Indicator */}
          <div className="mt-12 flex gap-2">
            {tourSteps.map((_, index) => (
              <div
                key={index}
                className={`h-2 rounded-full transition-all duration-300 ${
                  index === currentStep
                    ? 'w-12 bg-white'
                    : index < currentStep
                    ? 'w-8 bg-white/70'
                    : 'w-8 bg-white/30'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Progress Bar */}
        <div className="px-6 pb-4">
          <Progress value={progress} className="h-2 bg-white/20" />
        </div>

        {/* Controls */}
        <div className="bg-black/20 backdrop-blur-sm px-6 py-4 flex items-center justify-center gap-4">
          <Button
            onClick={handleRestart}
            variant="secondary"
            className="bg-white/20 hover:bg-white/30 text-white border-0"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Restart
          </Button>
          <Button
            onClick={handlePlayPause}
            size="lg"
            className="bg-white text-blue-600 hover:bg-white/90"
          >
            {isPlaying ? (
              <>
                <Pause className="w-5 h-5 mr-2" />
                Pause
              </>
            ) : (
              <>
                <Play className="w-5 h-5 mr-2" />
                Play
              </>
            )}
          </Button>
          <div className="text-white text-sm">
            Step {currentStep + 1} of {tourSteps.length}
          </div>
        </div>
      </div>
    </div>
  );
}
