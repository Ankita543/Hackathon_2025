import { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, MapPin, Star, Sparkles } from 'lucide-react';
import { Button } from './ui/button';
import { SearchData } from '../App';
import PropertyList from './PropertyList';
import MapView from './MapView';
import LocalLensModal from './LocalLensModal';
import VideoTourModal from './VideoTourModal';

interface ResultsPageProps {
  searchData: SearchData;
  onBack: () => void;
}

export default function ResultsPage({ searchData, onBack }: ResultsPageProps) {
  const [showLocalLens, setShowLocalLens] = useState(false);
  const [showVideoTour, setShowVideoTour] = useState(false);

  const tripDays = Math.ceil((searchData.checkOut.getTime() - searchData.checkIn.getTime()) / (1000 * 60 * 60 * 24));

  return (
    <div className="flex flex-col h-screen">
      {/* Header */}
      <header className="bg-white shadow-sm border-b z-10">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={onBack}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center">
                  <span className="text-white">V</span>
                </div>
                <span className="text-xl">vrbo</span>
              </div>
            </div>
            <nav className="flex items-center gap-6 text-sm">
              <a href="#" className="hover:text-blue-600 transition-colors">Trip Boards</a>
              <a href="#" className="hover:text-blue-600 transition-colors">List your property</a>
              <a href="#" className="hover:text-blue-600 transition-colors">Help</a>
              <a href="#" className="hover:text-blue-600 transition-colors">My trips</a>
              <a href="#" className="hover:text-blue-600 transition-colors">Sign in</a>
            </nav>
          </div>
        </div>
      </header>

      {/* Search Summary Bar */}
      <div className="bg-white border-b px-4 py-4">
        <div className="container mx-auto flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-4 flex-wrap">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-gray-500" />
              <span>{searchData.destination}</span>
            </div>
            <span className="text-gray-400">|</span>
            <span>{searchData.checkIn.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - {searchData.checkOut.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
            <span className="text-gray-400">|</span>
            <span>{searchData.guests} guests</span>
            <span className="text-gray-400">|</span>
            <span className="text-gray-600">{tripDays} days trip</span>
          </div>
          <div className="flex items-center gap-3">
            <Button
              onClick={() => setShowVideoTour(true)}
              size="icon"
              variant="outline"
              className="border-purple-600 text-purple-600 hover:bg-purple-50 transition-all duration-300 hover:shadow-lg w-10 h-10"
              title="Watch Video Tour"
            >
              <span className="text-lg">🎥</span>
            </Button>
            <Button
              onClick={() => setShowLocalLens(true)}
              className="bg-blue-600 hover:bg-blue-700 transition-all duration-300 hover:shadow-lg hover:scale-105"
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Local Lens
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Property List */}
        <motion.div 
          className="w-full lg:w-1/2 overflow-y-auto"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.1, ease: "easeOut" }}
        >
          <PropertyList destination={searchData.destination} />
        </motion.div>

        {/* Map */}
        <motion.div 
          className="hidden lg:block w-1/2 relative"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.2, ease: "easeOut" }}
        >
          <MapView destination={searchData.destination} />
        </motion.div>
      </div>

      {/* Local Lens Modal */}
      {showLocalLens && (
        <LocalLensModal
          searchData={searchData}
          onClose={() => setShowLocalLens(false)}
        />
      )}

      {/* Video Tour Modal */}
      {showVideoTour && (
        <VideoTourModal
          searchData={searchData}
          onClose={() => setShowVideoTour(false)}
        />
      )}
    </div>
  );
}
